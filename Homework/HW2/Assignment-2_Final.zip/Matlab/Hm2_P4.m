% Part (a)
%%%%%%%%%%%%%%%%%%%
% INSERT CODE BELOW
%%%%%%%%%%%%%%%%%
% define the function

% define the exact solution

% do MC integration

% report exact value and MC integration solution


% Part (b)


% Use this to plot errors. Use L-2 norm for error.
% plot(  ,  , alpha=0.7)
xlabel("N",'FontSize',15)
ylabel("Error",'FontSize',15)


%-- Part (c)


% use this to plot histograms. Plot 4 histograms.
hist(MC_int, bins=30)
xlabel("MC solution")

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INSERT CODE ABOVE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
