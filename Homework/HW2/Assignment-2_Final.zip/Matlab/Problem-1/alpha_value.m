%%%
%Statistical Computing for Scientists and Engineers
%Homework 1
%Fall 2018
%University of Notre Dame
%%%
function to_alpha= alpha_value(x,y)
to_alpha = exp(x)*beta_value(x,y);
end
