%%%
%Statistical Computing for Scientists and Engineers
%Homework 1
%Fall 2018
%University of Notre Dame
%%%
function log_prior = log_prior_value(A,B)
    %Add code below
log_prior = 

    %Add code above
end
