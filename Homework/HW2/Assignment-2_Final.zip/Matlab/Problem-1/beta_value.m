%%%
%Statistical Computing for Scientists and Engineers
%Homework 1
%Fall 2018
%University of Notre Dame
%%%
function to_beta = beta_value(x,y)
to_beta = exp(y)/(exp(x)+1);
end
